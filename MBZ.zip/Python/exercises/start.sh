#!/usr/bin/env bash

echo 'test' > 'test.txt'
git add test.txt
git commit -m "This is first exercise commit."
